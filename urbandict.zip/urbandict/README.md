# SearchTool
A simple chrome extension that let's you search for the selected text in UrbanDictionary.
