/* Copyright 2011 Google Inc. All Rights Reserved. */
(function () {
  var d, e, f, g, h, k, l, m, n, q, r, t, u, v, w, x, y, A = function () {
      var a = {};
      a.language = f.options[f.selectedIndex].value;
      a.popupDblclick = g.checked ? "true" : "false";
      a.popupSelect = l.checked ? "true" : "false";
      a.popupDblclickKey = k.options[k.selectedIndex].value;
      a.popupSelectKey = n.options[n.selectedIndex].value;
      a.storeHistory = q.checked ? "true" : "false";
      a.allowCrossExtensionHistory = u.checked ? "true" : "false";
      a.enableHttps = "true";
      window.localStorage.options = JSON.stringify(a);
      var b = document.getElementById("save-status");
      b.style.setProperty("-webkit-transition",
        "opacity 0s ease-out");
      b.style.opacity = 1;
      window.setTimeout(function () {
        b.style.setProperty("-webkit-transition", "opacity 0.4s ease-out");
        b.style.opacity = 0
      }, 1500);
      z(!1);
      chrome.extension.getBackgroundPage()["gdx.updateOptions"]()
    },
    G = function () {
      z(!1);
      var a = JSON.parse(window.localStorage.options);
      B(f, a.language);
      g.checked = "true" === a.popupDblclick;
      C();
      l.checked = "true" === a.popupSelect;
      D();
      B(k, a.popupDblclickKey);
      B(n, a.popupSelectKey);
      q.checked = "true" === a.storeHistory;
      u.checked = "true" === a.allowCrossExtensionHistory;
      E();
      chrome.storage.local.get("word-history", function (a) {
        r = a = Object.keys(a["word-history"])
          .length;
        t.innerHTML = a;
        F()
      })
    },
    F = function () {
      0 < r && q.checked ? (w.disabled = !1, y.disabled = !1) : 0 === r && (w.disabled = !0, y.disabled = !0)
    },
    H = function (a) {
      var b = "";
      a = a["word-history"];
      for (var c in a) var p = c.split("<"),
        I = a[c],
        b = b + p[0],
        b = b + "\t",
        b = b + p[1],
        b = b + "\t",
        b = b + p[2],
        b = b + "\t",
        b = b + I,
        b = b + "\n";
      x.href = window.URL.createObjectURL(new Blob([b], {
        type: "text/plain"
      }));
      b = x;
      c = document.createEvent("MouseEvents");
      c.initEvent("click", !0, !0);
      b.dispatchEvent(c)
    },
    J = function () {
      chrome.storage.local.get("word-history", H)
    },
    K = function () {
      chrome.storage.local.set({
        "word-history": {}
      });
      r = 0;
      t.innerHTML = 0;
      F()
    },
    B = function (a, b) {
      for (var c = 0, p = a.options.length; c < p; c++)
        if (a.options[c].value === b) {
          a.options[c].selected = !0;
          break
        }
    },
    z = function (a) {
      d.disabled = !a;
      e.disabled = !a
    },
    L = function () {
      z(!0)
    },
    C = function () {
      var a = g.checked;
      k.disabled = !a;
      h.className = a ? "" : "text-disabled"
    },
    D = function () {
      var a = l.checked;
      n.disabled = !a;
      m.className = a ? "" : "text-disabled"
    },
    E = function () {
      var a =
        q.checked;
      u.disabled = !a;
      v.className = a ? "" : "text-disabled";
      a || (u.checked = !1);
      w.disabled = !a;
      y.disabled = !a;
      F()
    };
  (function () {
    d = document.getElementById("save-btn");
    e = document.getElementById("reset-btn");
    f = document.getElementById("language-selector");
    g = document.getElementById("popup-dblclick-checkbox");
    h = document.getElementById("popup-dblclick-text");
    k = document.getElementById("popup-dblclick-key");
    l = document.getElementById("popup-select-checkbox");
    m = document.getElementById("popup-select-text");
    n = document.getElementById("popup-select-key");
    q = document.getElementById("store-history-checkbox");
    t = document.getElementById("num-words-in-history");
    u = document.getElementById("allow-cross-extension-history-checkbox");
    v = document.getElementById("allow-cross-extension-history-text");
    w = document.getElementById("download-history-btn");
    x = document.getElementById("download-history-link");
    y = document.getElementById("clear-history-btn");
    r = 0;
    d.addEventListener("click", A, !1);
    e.addEventListener("click", G, !1);
    g.addEventListener("change", function () {
      C()
    }, !1);
    l.addEventListener("change", function () {
      D()
    }, !1);
    q.addEventListener("change", function () {
      E()
    }, !1);
    w.addEventListener("click",
      J, !1);
    y.addEventListener("click", K, !1);
    document.getElementById("year")
      .innerText = (new Date)
      .getFullYear();
    for (var a = document.getElementsByTagName("input"), b = 0, c; c = a[b]; b++) c.addEventListener("change", L, !1);
    a = document.getElementsByTagName("select");
    for (b = 0; c = a[b]; b++) c.addEventListener("change", L, !1); - 1 !== window.navigator.platform.toLowerCase()
      .indexOf("mac") && (document.getElementById("popup-dblclick-key-ctrl")
        .innerHTML = "Command", document.getElementById("popup-select-key-ctrl")
        .innerHTML = "Command");
    G()
  })();
})();
