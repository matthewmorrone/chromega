/* Copyright 2011 Google Inc. All Rights Reserved. */
(function () {
  var e, k = function (a) {
      return a.replace(/^\s+|\s+$/g, "")
    },
    t = function (a) {
      if (a && a.tagName) {
        var b = a.tagName.toLowerCase();
        if ("input" === b || "textarea" === b) return !0
      }
      if (document.designMode && "on" === document.designMode.toLowerCase()) return !0;
      for (; a; a = a.parentNode)
        if (a.isContentEditable) return !0;
      return !1
    },
    u = function (a, b) {
      var c = new XMLHttpRequest;
      c.open("GET", a, !0);
      c.onload = function () {
        var a = null;
        200 === this.status && (a = c.response);
        return b(a)
      };
      c.send()
    },
    v = /[0-9A-Za-z]/,
    y = function () {
      u(chrome.runtime.getURL("content.min.css"),
        function (a) {
          var b = function (b) {
            this.K = b.instanceId;
            this.J = a;
            b = document.createElement("div");
            var f = document.createElement("a");
            f.target = "_blank";
            this.F = b.cloneNode(!1);
            this.B = document.createElement("audio");
            this.B.R = !0;
            this.b = b.cloneNode(!1);
            this.b.id = "gdx-bubble-host";
            this.D = this.b.createShadowRoot ? this.b.createShadowRoot() : this.b.webkitCreateShadowRoot();
            var d = document.createElement("style");
            d.innerHTML = this.J;
            this.D.appendChild(d);
            this.a = b.cloneNode(!1);
            this.a.id = "gdx-bubble-main";
            this.D.appendChild(this.a);
            this.g = b.cloneNode(!1);
            this.g.id = "gdx-bubble-query-row";
            this.C = b.cloneNode(!1);
            this.C.id = "gdx-bubble-query";
            this.i = b.cloneNode(!1);
            this.i.id = "gdx-bubble-audio-icon";
            this.g.appendChild(this.C);
            this.g.appendChild(this.i);
            this.l = b.cloneNode(!1);
            this.l.id = "gdx-bubble-meaning";
            this.f = b.cloneNode(!1);
            this.f.id = "gdx-bubble-options-tip";
            this.f.innerHTML = 'Tip: Didn\'t want this definition pop-up? Try setting a trigger key in <a href="#">Extension Options</a>.';
            this.m = b.cloneNode(!1);
            this.m.id = "gdx-bubble-more";
            this.h = f.cloneNode(!1);
            this.m.appendChild(this.h);
            this.c = b.cloneNode(!1);
            this.c.id = "gdx-bubble-attribution";
            this.s = f.cloneNode(!1);
            this.v = b.cloneNode(!1);
            this.c.appendChild(this.s);
            this.c.appendChild(this.v);
            this.w = b.cloneNode(!1);
            this.w.id = "gdx-bubble-close";
            this.a.appendChild(this.w);
            this.a.appendChild(this.g);
            this.a.appendChild(this.l);
            this.a.appendChild(this.f);
            this.a.appendChild(this.c);
            this.a.appendChild(this.m);
            this.A = b.cloneNode(!1);
            this.D.appendChild(this.A);
            this.I = w(b, "up");
            this.H = w(b, "down");
            x(this)
          }.bind(this);
          chrome.runtime.sendMessage({
            type: "initialize"
          }, b)
        }.bind(this))
    },
    z = [];
  e = y.prototype;
  e.J = "";
  e.u = 0;
  e.F = null;
  e.B = null;
  e.b = null;
  e.D = null;
  e.a = null;
  e.g = null;
  e.C = null;
  e.i = null;
  e.l = null;
  e.f = null;
  e.w = null;
  e.m = null;
  e.h = null;
  e.c = null;
  e.s = null;
  e.v = null;
  e.A = null;
  e.I = null;
  e.H = null;
  e.o = null;
  e.G = null;
  var x = function (a) {
      a.G = a.N.bind(a);
      window.addEventListener("resize", a.j.bind(a));
      document.addEventListener("mouseup", a.P.bind(a));
      document.addEventListener("dblclick", a.L.bind(a));
      document.addEventListener("keydown", a.O.bind(a));
      a.w.onclick = a.j.bind(a);
      a.i.onclick = function () {
        this.B.play()
      }.bind(a);
      a.f.querySelector("a")
        .onclick = function () {
          chrome.runtime.sendMessage({
            type: "openOptionsPage"
          }, function () {});
          return !1
        };
      var b = function (a) {
        a.preventDefault();
        a.stopPropagation()
      };
      a.i.onmousedown = b;
      a.w.onmousedown =
        b;
      chrome.runtime.onMessage.addListener(D);
      chrome.runtime.onMessage.addListener(a.G)
    },
    w = function (a, b) {
      var c = a.cloneNode(!1),
        f = a.cloneNode(!1),
        d = a.cloneNode(!1);
      c.id = "gdx-arrow-main";
      "up" === b ? (f.id = "gdx-bubble-arrow-inner-up", d.id = "gdx-bubble-arrow-outer-up") : (f.id = "gdx-bubble-arrow-inner-down", d.id = "gdx-bubble-arrow-outer-down");
      c.appendChild(f);
      c.appendChild(d);
      return c
    },
    E = function (a, b, c, f) {
      this.top = a;
      this.right = b;
      this.bottom = c;
      this.left = f
    },
    F = function (a) {
      a.a.style.left = "0";
      a.a.style.top = "0";
      var b =
        a.a.offsetWidth,
        c = a.a.offsetHeight,
        f = [window.pageXOffset, window.pageYOffset],
        d = f[0],
        g = [a.o.left + d, a.o.top + f[1]],
        n = a.o.bottom - a.o.top,
        A = g[0] + (a.o.right - a.o.left) / 2,
        f = d + document.documentElement.offsetWidth,
        l = A - b / 2;
      l + b > f && (l = f - b);
      l < d && (l = d);
      var r = g[1] - c - 12 + 1,
        m = g[1] + n + 12 - 1;
      a: if (b = new E(r, l + b, r + c, l), b.top < window.pageYOffset) b = !1;
        else {
          for (var c = document.getElementsByTagName("embed"), B = document.getElementsByTagName("object"), p = [window.pageXOffset, window.pageYOffset], C = p[0], p = p[1], q = 0, L = c.length + B.length; q <
            L; q++) {
            var h = (q < c.length ? c[q] : B[q - c.length])
              .getBoundingClientRect(),
              h = new E(h.top + p, h.right + C, h.bottom + p, h.left + C);
            if (b.bottom > h.top && h.bottom > b.top && b.left < h.right && h.left < b.right) {
              b = !1;
              break a
            }
          }
          b = !0
        }
      b ? (m = a.H, m.style.top = g[1] - 12 + "px") : (r = m, m = a.I, m.style.top = g[1] + n + "px");
      g = A - 12;
      m.style.left = g + "px";
      g - 5 > d && g + 24 + 5 < f && a.A.appendChild(m);
      a.a.style.top = r + "px";
      a.a.style.left = l + "px"
    };
  y.prototype.M = function (a) {
    if (a.eventKey === this.u) {
      this.j();
      this.i.className = "display-none";
      this.f.className = "display-none";
      this.m.className = "";
      this.c.className = "display-none";
      if (a.meaningObj) {
        var b = a.meaningObj;
        this.g.className = "";
        this.C.innerHTML = b.prettyQuery;
        this.l.innerHTML = b.meaningText;
        b.audio && (this.B.src = b.audio, this.i.className = "");
        this.h.href = b.moreUrl;
        this.h.innerHTML = "More &raquo;";
        b.attribution && ("translation" === b.type ? (this.v.innerHTML = b.attribution, this.s.className = "display-none", this.v.className =
          "") : (this.F.innerHTML = b.attribution, b = this.F.getElementsByTagName("a")[0], this.s.href = b.href, this.s.innerHTML = b.innerHTML.replace("http://", ""), this.s.className = "", this.v.className = "display-none"), this.c.className = "")
      }
      else this.g.className = "display-none", this.l.innerHTML = "No definition found.", this.h.href = "https://www.google.com/search?q=" + encodeURIComponent(a.sanitizedQuery), this.h.innerHTML = 'Search the web for "' + a.sanitizedQuery + '" \u00bb';
      a.showOptionsTip && (this.f.className = "");
      document.documentElement.appendChild(this.b);
      F(this)
    }
  };
  var G = function (a, b) {
      b === a.u && (a.l.innerHTML = "Dictionary is disabled for https pages.", a.h.href = "https://support.google.com/TODO", a.h.innerHTML = "More information \u00bb", a.m.className = "", a.g.className = "display-none", a.f.className = "display-none", a.c.className = "display-none", document.documentElement.appendChild(a.b), F(a))
    },
    H = function (a, b) {
      var c = b.getBoundingClientRect();
      a.o = new E(c.top, c.right, c.bottom, c.left)
    };
  y.prototype.j = function () {
    this.u++;
    var a = this.b;
    a && a.parentNode && a.parentNode.removeChild(a);
    for (a = this.A; a && a.hasChildNodes();) a.removeChild(a.childNodes[0])
  };
  y.prototype.O = function (a) {
    27 === a.keyCode && this.j()
  };
  var I = function (a, b) {
      return "none" === b || "alt" === b && a.altKey || "ctrl" === b && (-1 !== window.navigator.platform.toLowerCase()
        .indexOf("mac") ? a.metaKey : a.ctrlKey) || "shift" === b && a.shiftKey
    },
    J = function (a, b) {
      for (var c = b.target; c; c = c.parentNode)
        if (c === a.b) return !0;
      return !1
    },
    K = function (a, b, c, f) {
      var d;
      "mouseup" === c ? d = "true" === f.popupSelect && I(b, f.popupSelectKey) : "dblclick" === c ? d = "true" === f.popupSelect && I(b, f.popupSelectKey) ? !1 : "true" === f.popupDblclick && I(b, f.popupDblclickKey) : (console.warn("Unexpected eventType: " +
        c), d = !1);
      if (d) {
        d = 0;
        for (var g = z.length; d < g; d++)
          if (location.href.match(z[d])) return;
        if (!t(b.target)) {
          d = null;
          g = "";
          if (window.getSelection) {
            g = window.getSelection();
            if (1 > g.rangeCount) return;
            d = g.getRangeAt(0);
            g = k(g.toString())
          }
          else document.selection && (d = document.selection.createRange(), g = k(d.text));
          if (!(!g || 1 === g.length && 127 >= g.charCodeAt(0) && !g.match(v) || "dblclick" === c && -1 !== g.indexOf(" "))) {
            a.u++;
            var n = a.u;
            J(a, b) || H(a, d);
            "false" === f.enableHttps && 0 === location.href.lastIndexOf("https", 0) ? G(a, n) : (window.setTimeout(function () {
              n ===
                this.u && (this.l.innerHTML = "Searching...", this.g.className = "display-none", this.f.className = "display-none", this.m.className = "display-none", this.c.className = "display-none", document.documentElement.appendChild(this.b), F(this))
            }.bind(a), 300), chrome.runtime.sendMessage({
              type: "fetch_raw",
              eventKey: n,
              instanceId: a.K,
              query: g
            }, a.M.bind(a)))
          }
        }
      }
    };
  y.prototype.P = function (a) {
    J(this, a) || this.j();
    var b = function (b) {
      K(this, a, "mouseup", b.options)
    }.bind(this);
    chrome.runtime.sendMessage({
      type: "options"
    }, b)
  };
  y.prototype.L = function (a) {
    var b = function (b) {
      K(this, a, "dblclick", b.options)
    }.bind(this);
    chrome.runtime.sendMessage({
      type: "options"
    }, b)
  };
  var D = function (a, b, c) {
    "get_selection" === a.type && (a = k(window.getSelection()
      .toString())) && c({
      selection: a
    })
  };
  y.prototype.N = function (a) {
    "hide" === a.type && a.instanceId === this.K && this.j()
  };
  var M = M || !1;
  if (!M) {
    if (window.gdxBubbleInstance) {
      var N = window.gdxBubbleInstance;
      chrome.runtime.onMessage.removeListener(D);
      chrome.runtime.onMessage.removeListener(N.G);
      N.j()
    }
    window.gdxBubbleInstance = new y
  };
})();
