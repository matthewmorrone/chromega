
chrome.browserAction.onClicked.addListener(function() {
    chrome.storage.local.get(null, (res) => {
        left = (typeof res.left === "undefined" ? 400 : res.left)
        chrome.windows.update(chrome.windows.WINDOW_ID_CURRENT, {
            left: left,
            top: 0,
            width: screen.availWidth - left,
            height: screen.availHeight
        })
        chrome.windows.create({
            left: 0,
            top: 0,
            width: left,
            height: screen.availHeight
        }, function(window) {
            console.log(window);
            chrome.windows.update(window.id, {
                // focused: true
            }, function() {
                chrome.windows.onRemoved.addListener(function() {
                    console.log(arguments)
                })
            })
            chrome.tabs.update(window.tabs[0].tabId, {
                pinned: true,
                url: "https://ee.elunic.com/#location=!1/:5476fe1249c92"
            }, function() {

            })
        })
    });
});