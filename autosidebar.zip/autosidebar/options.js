function saveOptions(e) {
    left = Number(document.querySelector("#left").value)
    if (left >= 0 && left < (screen.availWidth - 320)) {
        chrome.storage.local.set({
            left: left
        })
        document.querySelector("#invalid").style.display = "none";
        document.querySelector("#saved").style.display = "block";
    } else {
        document.querySelector("#invalid").style.display = "block";
        document.querySelector("#saved").style.display = "none";
    }
}

function restoreOptions() {
    chrome.storage.local.get(null, (res) => {
        left = (typeof res.left === "undefined" ? 400 : res.left)
        document.querySelector("#left").value = left
    });
}

document.addEventListener("DOMContentLoaded", restoreOptions);
console.log(document.querySelectorAll("input"))
fields = document.querySelectorAll("input")
for (var i = 0; i < fields.length; i++) {
    fields[i].addEventListener("click", saveOptions)
    fields[i].addEventListener("keyup", saveOptions)
}